# ShikshaSaathi AI — Learn Anything, Understand Everything

> **Your Personal AI Learning Companion.** Turn difficult textbook pages into concepts you can actually understand, in simple English, Hindi or Hinglish.

Built for the hackathon theme **"Social Implementation of Technology"**. ShikshaSaathi ("study companion") helps students who cannot afford private tutoring get a patient, step-by-step explanation of what they are stuck on.

**AI model:** Google **Gemma 4** (`gemma-4-26b-a4b-it` by default) called from the Express backend through the Gemini API with the official [`@google/genai`](https://www.npmjs.com/package/@google/genai) SDK. The API key lives only in a server-side environment variable.

## Features

| Feature | What it does |
| --- | --- |
| **Snap & Learn** | Upload / drag-and-drop a textbook photo, preview it, pick a language, and Gemma 4 explains what is on the page. If the photo is blurry or unreadable, the student is asked for a clearer one instead of the model guessing. |
| **Explain Any Topic** | Step-by-step explanation with an example and key takeaways, plus an **Explain even more simply** button. |
| **Smart Notes** | Summary, definitions, key points and a revision checklist. Copy or save to My Learning. |
| **Quiz Me** | 5 multiple-choice questions. Correct answers are hidden until you submit; then you get a score and explanations for mistakes. |
| **My Learning** | Notes, quiz results and recent topics saved in your browser's LocalStorage, with simple progress stats. Sample data is only shown when you switch it on, and is always labelled. |
| **Accessibility** | Responsive layout, keyboard-friendly controls, skip link, visible focus, semantic landmarks, reduced-motion support, Hindi (Devanagari) font support. |

### Live mode vs demo mode

* **Live mode** — a valid `GEMINI_API_KEY` is set. The header shows **"Powered by Google Gemma 4"** and results are labelled *AI-generated*.
* **Demo mode** — no key (or `FORCE_DEMO_MODE=true`). The badge changes to **"Demo mode · sample outputs, no AI"**, and every output is labelled *Demo sample, not AI generated*. Your uploaded image is **not** analysed in demo mode.
* The app **never silently swaps Gemma 4 for another model**. If a live call fails (rate limit, network, bad key) you see the error. It does not fall back to demo text. The server also refuses to start if `GEMMA_MODEL` is not a Gemma 4 model.
* A response is marked as coming from Gemma 4 only after the actual API call succeeded.

## Architecture

```mermaid
flowchart LR
    S([Student]) --> C["React + Vite + Tailwind client"]
    C -- "POST /api/explain, snap, notes, quiz" --> E["Express server"]
    E -- "validate type, size, magic bytes" --> E
    E -- "@google/genai SDK" --> G["Gemini API: gemma-4-26b-a4b-it"]
    G --> E
    E -- "JSON + provenance flag (live or demo)" --> C
    C <--> L[("LocalStorage: notes, quiz results, topics")]
    K[".env: GEMINI_API_KEY (server only)"] -.-> E
```

```
shikshasaathi-ai/
├── client/            React + Vite + TypeScript + Tailwind UI
│   └── src/{pages,components,lib}
├── server/            Express API + Gemma 4 service
│   ├── src/           app.js, gemma.js, prompts.js, demo.js, validate.js, config.js
│   └── test/          node:test suite (no network or API key needed)
├── .env.example       placeholders only
├── LICENSE            MIT
└── README.md
```

## Quick start

Requires **Node.js 18.18+** (tested on Node 22).

```bash
# 1. Get the code
git clone https://github.com/<your-username>/shikshasaathi-ai.git
cd shikshasaathi-ai

# 2. Install everything (root + server + client)
npm run install:all

# 3. Configure your key (skip this step to try demo mode)
cp .env.example .env
#    then edit .env and set GEMINI_API_KEY=<your key from https://aistudio.google.com/apikey>

# 4. Start the backend (http://localhost:8787) and the frontend (http://localhost:5173)
npm run dev
```

Open <http://localhost:5173> and click **Start Learning**.

### Production-style run (single server)

```bash
npm run build     # type-checks and builds client/dist
npm start         # Express serves the API and the built client on http://localhost:8787
```

## Testing

```bash
# Server unit/integration tests. Use a fake Gemma client, so no key or internet is needed.
npm test

# Type-check the client
npm run typecheck

# Production build
npm run build

# REAL Gemma 4 check (needs GEMINI_API_KEY in .env): sends one text and one image request
npm run test:gemma
```

With the server running you can also check the live connection:

```bash
curl http://localhost:8787/api/status          # {"mode":"live","model":"gemma-4-26b-a4b-it",...}
curl http://localhost:8787/api/health/gemma    # makes one real Gemma call (503 in demo mode)

curl -X POST http://localhost:8787/api/explain \
  -H "Content-Type: application/json" \
  -d '{"topic":"Why is the sky blue?","language":"hinglish"}'
```

If image upload fails against the live API, set `GEMMA_IMAGE_MODE=files` in `.env` to use the Gemini Files API instead of inline base64 (the Files API is the method shown in Google's Gemma docs).

## API

| Method & path | Body | Notes |
| --- | --- | --- |
| `GET /api/status` | – | `mode` (`live`/`demo`), `model` (only in live mode) |
| `POST /api/explain` | `{topic, language, simpler?, previous?}` | `language`: `english`, `hindi`, `hinglish` |
| `POST /api/snap` | `{imageBase64, mimeType, language, question?}` | JPEG/PNG/WebP, max `MAX_IMAGE_MB` |
| `POST /api/notes` | `{topic?, content, language}` | |
| `POST /api/quiz` | `{topic, content?, language}` | returns 5 questions |
| `GET /api/health/gemma` | – | one live ping; 503 in demo mode |

## Security & reliability

* API key read from server env only; never sent to the browser or committed (`.env` is git-ignored, `.env.example` holds placeholders).
* Image uploads: MIME allow-list, real file-signature check, size limit (client also resizes big phone photos).
* Input length limits, JSON body limit, per-IP rate limiting.
* Friendly handling of rate limits (429), auth errors, timeouts and network failures.
* AI output is rendered as Markdown with raw HTML disabled; system prompt tells the model to ignore instructions found inside images or pasted text.
* Every result carries an honest provenance label and a reminder to verify important facts.

## Push to GitHub

```bash
git init
git add .
git status                      # confirm .env is NOT listed
git commit -m "Initial commit: ShikshaSaathi AI"
git branch -M main
git remote add origin https://github.com/<your-username>/shikshasaathi-ai.git
git push -u origin main
```

(Create the empty repository on GitHub first, or run `gh repo create shikshasaathi-ai --public --source=. --push` if you use the GitHub CLI.)

## Social impact

Private tutoring is expensive, and many students (especially in non-English-medium or low-income households) have nobody to ask when a textbook page does not make sense. ShikshaSaathi aims to give every student with a phone a patient explainer that:

* works from a **photo of the actual textbook page**,
* explains in the **language they think in** (simple English, Hindi, Hinglish),
* checks understanding with quizzes and keeps notes **on their own device**, with no account and no personal data collected by the server.

## Limitations (please read)

* **AI can be wrong.** Gemma 4 may make factual mistakes; the app labels outputs and asks students to verify with a textbook or teacher. It is a study aid, not an authority.
* **Image reading quality depends on the photo** (light, focus, handwriting). Very dense or low-quality pages may be reported as unclear.
* **Quiz answers are held in the browser.** Correct answers are hidden in the UI until you submit, but a technically skilled student could inspect network responses. Fine for self-study, not for graded exams.
* **No accounts or sync.** Progress lives in one browser's LocalStorage and is lost if site data is cleared.
* **Needs internet and a Gemini API key** for live mode; free-tier quotas can rate-limit busy demos.
* **Hindi/Hinglish quality** has not been reviewed by teachers or native-speaker educators.
* Not yet tested here: real Gemma 4 calls (no API key was available while building). Run `npm run test:gemma` to verify your own key.
* `npm audit` reports a dev-only advisory in the Vite 5 / esbuild dev server; it does not affect the production build.

## Future scope

* Offline-first PWA and low-bandwidth mode; more Indian languages (Tamil, Bengali, Marathi…).
* Voice input and read-aloud for students with low literacy or visual impairments.
* Curriculum alignment (NCERT/state boards) and teacher-reviewed answer sets.
* Server-side quiz grading, optional teacher dashboards, spaced-repetition revision.
* Streaming responses and an on-device Gemma option for fully offline use.

## License

[MIT](LICENSE). Gemma is provided by Google under its own terms; see <https://ai.google.dev/gemma/terms>.

AI-generated content in this app is produced by Gemma 4 and may contain errors.
