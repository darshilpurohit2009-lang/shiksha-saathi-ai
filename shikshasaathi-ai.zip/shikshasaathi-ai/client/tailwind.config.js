/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        cream: { 50: '#FEFCF8', 100: '#FBF7F0', 200: '#F3ECDF', 300: '#E8DEC9' },
        ink: { 900: '#0B1B3A', 800: '#14264A', 700: '#26385C', 600: '#3B4E75', 500: '#51628A' },
      },
      fontFamily: {
        sans: ['Inter', '"Noto Sans Devanagari"', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        display: ['Fraunces', '"Noto Sans Devanagari"', 'Georgia', 'serif'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(11,27,58,0.04), 0 8px 24px -12px rgba(11,27,58,0.12)',
      },
      keyframes: {
        rise: { '0%': { opacity: '0', transform: 'translateY(8px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
      },
      animation: { rise: 'rise 0.45s ease-out both' },
    },
  },
  plugins: [],
};
