import { useState, type ReactNode } from 'react';
import { Camera, GraduationCap, History, Home, LayoutDashboard, Lightbulb, ListChecks, Menu, NotebookPen, X } from 'lucide-react';
import { useApp } from '../lib/app';
import type { View } from '../lib/types';
import { ModeBadge } from './ui';

const NAV: Array<{ view: View; label: string; icon: typeof Home }> = [
  { view: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { view: 'snap', label: 'Snap & Learn', icon: Camera },
  { view: 'explain', label: 'Explain a Topic', icon: Lightbulb },
  { view: 'notes', label: 'Smart Notes', icon: NotebookPen },
  { view: 'quiz', label: 'Quiz Me', icon: ListChecks },
  { view: 'learning', label: 'My Learning', icon: History },
];

export function Logo({ onClick }: { onClick?: () => void }) {
  const inner = (
    <>
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-teal-500 to-teal-800 text-white shadow-sm">
        <GraduationCap className="h-5 w-5" aria-hidden />
      </span>
      <span className="font-display text-xl font-bold text-ink-900">
        Shiksha<span className="text-teal-700">Saathi</span>
      </span>
    </>
  );
  return onClick ? (
    <button type="button" onClick={onClick} className="flex items-center gap-2.5" aria-label="ShikshaSaathi AI home">
      {inner}
    </button>
  ) : (
    <div className="flex items-center gap-2.5">{inner}</div>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { view, go, status } = useApp();
  const [open, setOpen] = useState(false);

  const nav = (
    <nav aria-label="Main" className="flex flex-col gap-1">
      {NAV.map(({ view: v, label, icon: Icon }) => {
        const active = view === v;
        return (
          <button
            key={v}
            type="button"
            aria-current={active ? 'page' : undefined}
            onClick={() => {
              go(v);
              setOpen(false);
            }}
            className={`flex items-center gap-3 rounded-xl px-3.5 py-3 text-left text-[0.95rem] font-semibold transition ${
              active ? 'bg-teal-700 text-white shadow-sm' : 'text-ink-700 hover:bg-cream-200'
            }`}
          >
            <Icon className="h-5 w-5" aria-hidden />
            {label}
          </button>
        );
      })}
      <button
        type="button"
        onClick={() => {
          go('landing');
          setOpen(false);
        }}
        className="mt-2 flex items-center gap-3 rounded-xl px-3.5 py-3 text-left text-sm font-medium text-ink-600 hover:bg-cream-200"
      >
        <Home className="h-5 w-5" aria-hidden />
        Home
      </button>
    </nav>
  );

  return (
    <div className="min-h-screen lg:flex">
      <a
        href="#main"
        className="sr-only z-50 rounded-lg bg-white px-4 py-2 font-semibold focus:not-sr-only focus:fixed focus:left-3 focus:top-3"
      >
        Skip to content
      </a>

      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-72 shrink-0 flex-col justify-between border-r border-cream-300/70 bg-cream-50 p-5 lg:flex">
        <div className="space-y-8">
          <Logo onClick={() => go('landing')} />
          {nav}
        </div>
        <div className="space-y-2">
          <ModeBadge status={status} />
          <p className="text-xs text-ink-500">AI can make mistakes. Always verify important facts.</p>
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="sticky top-0 z-30 flex items-center justify-between border-b border-cream-300/70 bg-cream-50/95 px-4 py-3 backdrop-blur lg:hidden">
        <Logo onClick={() => go('landing')} />
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? 'Close menu' : 'Open menu'}
          className="grid h-11 w-11 place-items-center rounded-xl border border-cream-300 bg-white"
        >
          {open ? <X className="h-5 w-5" aria-hidden /> : <Menu className="h-5 w-5" aria-hidden />}
        </button>
      </div>
      {open && (
        <div id="mobile-nav" className="z-20 border-b border-cream-300 bg-cream-50 p-4 lg:hidden">
          {nav}
          <div className="mt-4">
            <ModeBadge status={status} />
          </div>
        </div>
      )}

      <main id="main" tabIndex={-1} className="min-w-0 flex-1 px-4 py-6 sm:px-8 lg:px-12 lg:py-10">
        <div className="mx-auto max-w-4xl">{children}</div>
      </main>
    </div>
  );
}
