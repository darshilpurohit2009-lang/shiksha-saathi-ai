import { useState, type ReactNode } from 'react';
import ReactMarkdown from 'react-markdown';
import { AlertTriangle, Check, Copy, Info, Loader2, ShieldCheck, Sparkles } from 'lucide-react';
import { LANGUAGE_LABELS, type ApiMeta, type Language, type Status } from '../lib/types';

export function Spinner({ label }: { label: string }) {
  return (
    <div role="status" aria-live="polite" className="flex items-center gap-3 text-ink-600">
      <Loader2 className="h-5 w-5 animate-spin text-teal-700" aria-hidden />
      <span>{label}</span>
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="notice notice-error flex items-start gap-3">
      <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
      <div className="flex-1">
        <p className="font-semibold">Something went wrong</p>
        <p>{message}</p>
        {onRetry && (
          <button type="button" onClick={onRetry} className="mt-2 font-semibold underline underline-offset-2">
            Try again
          </button>
        )}
      </div>
    </div>
  );
}

export function PageHeader({ title, subtitle, icon }: { title: string; subtitle: string; icon?: ReactNode }) {
  return (
    <header className="mb-6 animate-rise">
      <div className="flex items-center gap-3">
        {icon && (
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-teal-700/10 text-teal-800" aria-hidden>
            {icon}
          </span>
        )}
        <h1 className="font-display text-3xl font-bold text-ink-900">{title}</h1>
      </div>
      <p className="mt-2 max-w-2xl text-ink-600">{subtitle}</p>
    </header>
  );
}

export function LanguagePicker({ value, onChange }: { value: Language; onChange: (l: Language) => void }) {
  const options = Object.keys(LANGUAGE_LABELS) as Language[];
  return (
    <fieldset>
      <legend className="label">Explain in</legend>
      <div className="inline-flex flex-wrap gap-1 rounded-xl border border-cream-300 bg-cream-200/60 p-1">
        {options.map((l) => (
          <label
            key={l}
            className={`cursor-pointer rounded-lg px-4 py-2 text-sm font-semibold transition focus-within:outline focus-within:outline-2 focus-within:outline-teal-700 ${
              value === l ? 'bg-white text-teal-800 shadow-sm' : 'text-ink-600 hover:text-ink-900'
            }`}
          >
            <input
              type="radio"
              name="language"
              value={l}
              checked={value === l}
              onChange={() => onChange(l)}
              className="sr-only"
            />
            {LANGUAGE_LABELS[l]}
          </label>
        ))}
      </div>
    </fieldset>
  );
}

export function Markdown({ children }: { children: string }) {
  // react-markdown does not render raw HTML by default, so AI output cannot inject markup.
  return (
    <div className="prose-ss">
      <ReactMarkdown>{children}</ReactMarkdown>
    </div>
  );
}

/** Honest provenance note shown under every result. */
export function AiNotice({ meta }: { meta: ApiMeta }) {
  if (meta.aiGenerated) {
    return (
      <div role="note" className="notice notice-live flex items-start gap-2">
        <Sparkles className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
        <p>
          <strong>AI-generated</strong> by Google Gemma 4 (<code>{meta.model}</code>). AI can make mistakes, so please
          verify important facts with your textbook or teacher.
        </p>
      </div>
    );
  }
  return (
    <div role="note" className="notice notice-demo flex items-start gap-2">
      <Info className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
      <p>
        <strong>Demo sample, not AI generated.</strong> This text was written by the project authors. Add a Gemma API
        key on the server to get live answers.
      </p>
    </div>
  );
}

export function ModeBadge({ status, compact = false }: { status: Status; compact?: boolean }) {
  const base = 'inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold';
  if (status.state === 'live') {
    return (
      <span className={`${base} bg-teal-700 text-white`}>
        <ShieldCheck className="h-3.5 w-3.5" aria-hidden />
        Powered by Google Gemma 4
        {!compact && status.model && <span className="font-normal opacity-80">· Live AI</span>}
      </span>
    );
  }
  if (status.state === 'demo') {
    return (
      <span className={`${base} bg-amber-100 text-amber-900 ring-1 ring-amber-300`}>
        <Info className="h-3.5 w-3.5" aria-hidden />
        Demo mode · sample outputs, no AI
      </span>
    );
  }
  if (status.state === 'offline') {
    return (
      <span className={`${base} bg-red-100 text-red-900 ring-1 ring-red-300`}>
        <AlertTriangle className="h-3.5 w-3.5" aria-hidden />
        Server unreachable
      </span>
    );
  }
  return <span className={`${base} bg-cream-200 text-ink-600`}>Checking server…</span>;
}

export function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [done, setDone] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setDone(true);
    window.setTimeout(() => setDone(false), 2000);
  };
  return (
    <button type="button" onClick={copy} className="btn-secondary px-4 py-2 text-sm">
      {done ? <Check className="h-4 w-4 text-teal-700" aria-hidden /> : <Copy className="h-4 w-4" aria-hidden />}
      <span aria-live="polite">{done ? 'Copied' : label}</span>
    </button>
  );
}

export function EmptyState({ title, hint }: { title: string; hint: string }) {
  return (
    <div className="rounded-xl border border-dashed border-cream-300 bg-cream-50 px-4 py-8 text-center">
      <p className="font-semibold text-ink-800">{title}</p>
      <p className="mt-1 text-sm text-ink-600">{hint}</p>
    </div>
  );
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime())
    ? ''
    : d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}
