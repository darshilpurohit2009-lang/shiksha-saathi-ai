import type { Stats } from '../lib/stats';

export function StatTiles({ stats, sample = false }: { stats: Stats; sample?: boolean }) {
  const items = [
    { label: 'Topics studied', value: String(stats.topics) },
    { label: 'Notes saved', value: String(stats.notes) },
    { label: 'Quizzes taken', value: String(stats.quizzes) },
    { label: 'Average quiz score', value: stats.averagePercent === null ? '—' : `${stats.averagePercent}%` },
  ];
  return (
    <div>
      {sample && (
        <p className="mb-2 inline-block rounded-full bg-amber-100 px-3 py-1 text-xs font-bold uppercase tracking-wide text-amber-900">
          Sample data, not your progress
        </p>
      )}
      <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {items.map((i) => (
          <div key={i.label} className="card p-4">
            <dt className="text-sm text-ink-600">{i.label}</dt>
            <dd className="mt-1 font-display text-3xl font-bold text-ink-900">{i.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
