import { useEffect, useState, type FormEvent, type KeyboardEvent } from 'react';
import { Lightbulb, ListChecks, NotebookPen, Sparkles } from 'lucide-react';
import { api, ApiError } from '../lib/api';
import { useApp } from '../lib/app';
import type { ExplainResponse } from '../lib/types';
import { AiNotice, ErrorBox, LanguagePicker, Markdown, PageHeader, Spinner } from '../components/ui';

const EXAMPLES = ['Photosynthesis', "Newton's third law", 'What is a fraction?', 'How do vaccines work?'];

export function Explain() {
  const { language, setLanguage, study, setStudy, addTopic, go } = useApp();
  const [topic, setTopic] = useState(study.topic);
  const [result, setResult] = useState<ExplainResponse | null>(null);
  const [loading, setLoading] = useState<'explain' | 'simpler' | null>(null);
  const [error, setError] = useState('');

  // If a topic was handed over from another page (e.g. the dashboard), keep it in the box.
  useEffect(() => {
    if (study.topic && !topic) setTopic(study.topic);
  }, [study.topic, topic]);

  async function run(simpler: boolean) {
    const t = topic.trim();
    if (!t) {
      setError('Please type a topic or question first.');
      return;
    }
    setError('');
    setLoading(simpler ? 'simpler' : 'explain');
    try {
      const res = await api.explain({ topic: t, language, simpler, previous: simpler ? result?.markdown : undefined });
      setResult(res);
      setStudy({ topic: t, content: res.markdown });
      if (!simpler) addTopic(t, 'explain', res.mode);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Unexpected error. Please try again.');
    } finally {
      setLoading(null);
    }
  }

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!loading) void run(false);
  };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !loading) void run(false);
  };

  return (
    <>
      <PageHeader
        title="Explain Any Topic"
        subtitle="Type a topic or a question. You will get a step-by-step explanation with an example and key takeaways."
        icon={<Lightbulb className="h-6 w-6" />}
      />

      <form onSubmit={onSubmit} className="card space-y-5 p-5 sm:p-6">
        <div>
          <label htmlFor="topic" className="label">
            What do you want to understand?
          </label>
          <textarea
            id="topic"
            className="input min-h-[96px] resize-y"
            maxLength={500}
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            onKeyDown={onKey}
            placeholder="e.g. Why does the moon have phases?"
          />
          <div className="mt-2 flex flex-wrap gap-2" aria-label="Example topics">
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => setTopic(ex)}
                className="rounded-full border border-cream-300 bg-cream-50 px-3 py-1 text-sm text-ink-700 hover:bg-cream-200"
              >
                {ex}
              </button>
            ))}
          </div>
        </div>
        <LanguagePicker value={language} onChange={setLanguage} />
        <button type="submit" className="btn-primary" disabled={loading !== null}>
          <Sparkles className="h-5 w-5" aria-hidden /> Explain it
        </button>
        <span className="ml-3 hidden text-xs text-ink-500 sm:inline">Tip: Ctrl/⌘ + Enter</span>
      </form>

      <div className="mt-6 space-y-4" aria-live="polite">
        {loading && <Spinner label={loading === 'simpler' ? 'Making it even simpler…' : 'Thinking through your topic…'} />}
        {error && <ErrorBox message={error} onRetry={() => void run(false)} />}

        {result && !loading && (
          <article className="card animate-rise p-5 sm:p-7">
            <Markdown>{result.markdown}</Markdown>
            <div className="mt-6 flex flex-wrap gap-2 border-t border-cream-300/70 pt-5">
              <button type="button" className="btn-secondary px-4 py-2 text-sm" onClick={() => void run(true)}>
                <Sparkles className="h-4 w-4" aria-hidden /> Explain even more simply
              </button>
              <button type="button" className="btn-secondary px-4 py-2 text-sm" onClick={() => go('notes')}>
                <NotebookPen className="h-4 w-4" aria-hidden /> Make notes
              </button>
              <button type="button" className="btn-secondary px-4 py-2 text-sm" onClick={() => go('quiz')}>
                <ListChecks className="h-4 w-4" aria-hidden /> Quiz me
              </button>
            </div>
            <div className="mt-4">
              <AiNotice meta={result} />
            </div>
          </article>
        )}
      </div>
    </>
  );
}
