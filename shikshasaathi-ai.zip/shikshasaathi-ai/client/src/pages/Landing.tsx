import { ArrowRight, Camera, Globe2, Lightbulb, ListChecks, NotebookPen, ShieldCheck } from 'lucide-react';
import { useApp } from '../lib/app';
import { Logo } from '../components/Layout';
import { ModeBadge } from '../components/ui';

const FEATURES = [
  { icon: Camera, title: 'Snap & Learn', text: 'Photograph a textbook page or diagram and get a clear, step-by-step explanation.' },
  { icon: Lightbulb, title: 'Explain Any Topic', text: 'Ask anything. Get examples and key takeaways, and tap once for an even simpler version.' },
  { icon: NotebookPen, title: 'Smart Notes', text: 'Turn what you studied into short notes, definitions and a revision checklist.' },
  { icon: ListChecks, title: 'Quiz Me', text: 'Five questions to check your understanding, with explanations for what you missed.' },
];

export function Landing() {
  const { go, status } = useApp();
  return (
    <div className="relative overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-gradient-to-br from-teal-300/40 via-teal-200/30 to-amber-200/30 blur-3xl"
      />
      <div className="relative mx-auto max-w-6xl px-5 pb-20 pt-6 sm:px-8">
        <header className="flex items-center justify-between">
          <Logo />
          <ModeBadge status={status} />
        </header>

        <main id="main" tabIndex={-1} className="pt-16 sm:pt-24">
          <section className="max-w-3xl animate-rise">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-white px-3.5 py-1.5 text-sm font-semibold text-teal-800 shadow-card">
              <Globe2 className="h-4 w-4" aria-hidden /> English · हिन्दी · Hinglish
            </p>
            <h1 className="font-display text-4xl font-bold leading-tight text-ink-900 sm:text-6xl">
              Your Personal AI Learning Companion
            </h1>
            <p className="mt-5 max-w-2xl text-lg text-ink-600 sm:text-xl">
              Turn difficult textbook pages into concepts you can actually understand.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button type="button" className="btn-primary px-7 py-4 text-lg" onClick={() => go('dashboard')}>
                Start Learning <ArrowRight className="h-5 w-5" aria-hidden />
              </button>
              <button type="button" className="btn-secondary px-6 py-4" onClick={() => go('explain')}>
                Try a quick question
              </button>
            </div>
            {status.state === 'demo' && (
              <p className="mt-5 max-w-xl text-sm text-amber-900">
                This server is running in <strong>demo mode</strong>: you will see clearly labelled sample outputs, not
                live AI answers.
              </p>
            )}
          </section>

          <section aria-labelledby="features" className="mt-20">
            <h2 id="features" className="font-display text-2xl font-bold">
              Everything a good tutor would help you with
            </h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {FEATURES.map(({ icon: Icon, title, text }, i) => (
                <article key={title} className="card animate-rise p-6" style={{ animationDelay: `${i * 80}ms` }}>
                  <span className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-teal-700/10 text-teal-800">
                    <Icon className="h-5 w-5" aria-hidden />
                  </span>
                  <h3 className="text-lg font-bold">{title}</h3>
                  <p className="mt-1 text-ink-600">{text}</p>
                </article>
              ))}
            </div>
          </section>

          <section className="card mt-16 flex flex-col gap-4 bg-ink-900 p-8 text-cream-100 sm:flex-row sm:items-center">
            <ShieldCheck className="h-10 w-10 shrink-0 text-teal-300" aria-hidden />
            <div>
              <h2 className="font-display text-xl font-bold">Built for students who cannot afford tutoring</h2>
              <p className="mt-1 text-cream-200/90">
                Free to run, works on a phone, and explains in the language you think in. AI can make mistakes, so
                ShikshaSaathi always reminds you to double-check important facts with your textbook or teacher.
              </p>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
