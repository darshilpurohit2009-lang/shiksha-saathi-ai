import { useMemo, useState, type FormEvent } from 'react';
import { CheckCircle2, ListChecks, RotateCcw, Sparkles, XCircle } from 'lucide-react';
import { api, ApiError } from '../lib/api';
import { useApp } from '../lib/app';
import type { QuizResponse } from '../lib/types';
import { AiNotice, ErrorBox, LanguagePicker, PageHeader, Spinner } from '../components/ui';

type Phase = 'setup' | 'answering' | 'results';

export function Quiz() {
  const { language, setLanguage, study, addQuiz, go } = useApp();
  const [topic, setTopic] = useState(study.topic);
  const [quiz, setQuiz] = useState<QuizResponse | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [phase, setPhase] = useState<Phase>('setup');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const questions = quiz?.questions ?? [];
  const answered = Object.keys(answers).length;
  const score = useMemo(
    () => questions.reduce((s, q) => s + (answers[q.id] === q.correctIndex ? 1 : 0), 0),
    [questions, answers]
  );

  async function start(e?: FormEvent) {
    e?.preventDefault();
    const t = topic.trim();
    if (!t) {
      setError('Please enter the topic you want to be quizzed on.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      // Reuse the material from the last explanation only if it is about this same topic.
      const content = study.topic.trim().toLowerCase() === t.toLowerCase() ? study.content : '';
      const res = await api.quiz({ topic: t, content: content || undefined, language });
      setQuiz(res);
      setAnswers({});
      setPhase('answering');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unexpected error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    if (!quiz || answered < questions.length) return;
    addQuiz({ topic: topic.trim(), score, total: questions.length, mode: quiz.mode });
    setPhase('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function again() {
    setQuiz(null);
    setAnswers({});
    setPhase('setup');
  }

  return (
    <>
      <PageHeader
        title="Quiz Me"
        subtitle="Five multiple-choice questions to check what you understood. Answers are revealed only after you submit."
        icon={<ListChecks className="h-6 w-6" />}
      />

      {phase === 'setup' && (
        <form onSubmit={start} className="card space-y-5 p-5 sm:p-6">
          <div>
            <label htmlFor="quiz-topic" className="label">
              Topic
            </label>
            <input
              id="quiz-topic"
              className="input"
              maxLength={300}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Photosynthesis"
            />
          </div>
          <LanguagePicker value={language} onChange={setLanguage} />
          <button type="submit" className="btn-primary" disabled={loading}>
            <Sparkles className="h-5 w-5" aria-hidden /> Create my quiz
          </button>
        </form>
      )}

      <div className="mt-6 space-y-4" aria-live="polite">
        {loading && <Spinner label="Writing your questions…" />}
        {error && <ErrorBox message={error} onRetry={phase === 'setup' ? () => void start() : undefined} />}
      </div>

      {quiz && phase === 'answering' && (
        <form onSubmit={submit} className="space-y-5">
          {quiz.note && <p className="notice notice-demo">{quiz.note}</p>}
          {questions.map((q, i) => (
            <fieldset key={q.id} className="card animate-rise p-5 sm:p-6">
              <legend className="px-1 text-lg font-bold">
                <span className="text-teal-800">Q{i + 1}.</span> {q.question}
              </legend>
              <div className="mt-3 space-y-2">
                {q.options.map((opt, oi) => (
                  <label
                    key={oi}
                    className={`flex cursor-pointer items-start gap-3 rounded-xl border px-4 py-3 transition focus-within:outline focus-within:outline-2 focus-within:outline-teal-700 ${
                      answers[q.id] === oi ? 'border-teal-700 bg-teal-50' : 'border-cream-300 bg-white hover:bg-cream-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name={q.id}
                      checked={answers[q.id] === oi}
                      onChange={() => setAnswers((a) => ({ ...a, [q.id]: oi }))}
                      className="mt-1.5 h-4 w-4 accent-teal-700"
                    />
                    <span>
                      <span className="mr-2 font-semibold text-ink-500">{String.fromCharCode(65 + oi)}.</span>
                      {opt}
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>
          ))}
          <div className="flex flex-wrap items-center gap-4">
            <button type="submit" className="btn-primary" disabled={answered < questions.length}>
              Submit answers
            </button>
            <p className="text-sm text-ink-600" aria-live="polite">
              {answered} of {questions.length} answered
            </p>
          </div>
          <AiNotice meta={quiz} />
        </form>
      )}

      {quiz && phase === 'results' && (
        <section className="space-y-5" aria-label="Quiz results">
          <div className="card animate-rise bg-gradient-to-br from-teal-50 to-white p-6 text-center">
            <p className="text-sm font-semibold uppercase tracking-wide text-teal-800">Your score</p>
            <p className="mt-1 font-display text-5xl font-bold text-ink-900">
              {score} <span className="text-2xl text-ink-500">/ {questions.length}</span>
            </p>
            <p className="mt-2 text-ink-600">
              {score === questions.length
                ? 'Perfect! You understood this topic really well.'
                : score >= 3
                  ? 'Good work. Review the ones you missed below.'
                  : 'Keep going. Read the explanations below and try again.'}
            </p>
          </div>

          {questions.map((q, i) => {
            const mine = answers[q.id];
            const right = mine === q.correctIndex;
            return (
              <article key={q.id} className="card p-5 sm:p-6">
                <h2 className="flex items-start gap-2 text-lg font-bold">
                  {right ? (
                    <CheckCircle2 className="mt-1 h-5 w-5 shrink-0 text-teal-700" aria-label="Correct" />
                  ) : (
                    <XCircle className="mt-1 h-5 w-5 shrink-0 text-red-700" aria-label="Incorrect" />
                  )}
                  <span>
                    Q{i + 1}. {q.question}
                  </span>
                </h2>
                <ul className="mt-3 space-y-1.5">
                  {q.options.map((opt, oi) => {
                    const isRight = oi === q.correctIndex;
                    const isMine = oi === mine;
                    return (
                      <li
                        key={oi}
                        className={`rounded-lg border px-3 py-2 text-[0.95rem] ${
                          isRight
                            ? 'border-teal-600 bg-teal-50 text-teal-900'
                            : isMine
                              ? 'border-red-400 bg-red-50 text-red-900'
                              : 'border-cream-300 text-ink-700'
                        }`}
                      >
                        <span className="font-semibold">{String.fromCharCode(65 + oi)}.</span> {opt}
                        {isRight && <span className="ml-2 text-xs font-bold">(correct answer)</span>}
                        {isMine && !isRight && <span className="ml-2 text-xs font-bold">(your answer)</span>}
                      </li>
                    );
                  })}
                </ul>
                {!right && q.explanation && (
                  <p className="mt-3 rounded-lg bg-cream-100 px-4 py-3 text-ink-800">
                    <strong>Why: </strong>
                    {q.explanation}
                  </p>
                )}
              </article>
            );
          })}

          <AiNotice meta={quiz} />
          <div className="flex flex-wrap gap-3">
            <button type="button" className="btn-primary" onClick={again}>
              <RotateCcw className="h-5 w-5" aria-hidden /> New quiz
            </button>
            <button type="button" className="btn-secondary" onClick={() => go('learning')}>
              See My Learning
            </button>
          </div>
        </section>
      )}
    </>
  );
}
