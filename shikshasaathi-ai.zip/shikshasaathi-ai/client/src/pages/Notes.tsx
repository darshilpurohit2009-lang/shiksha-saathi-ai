import { useState, type FormEvent } from 'react';
import { Check, NotebookPen, Save, Sparkles } from 'lucide-react';
import { api, ApiError } from '../lib/api';
import { useApp } from '../lib/app';
import type { NotesResponse } from '../lib/types';
import { AiNotice, CopyButton, ErrorBox, LanguagePicker, Markdown, PageHeader, Spinner } from '../components/ui';

export function Notes() {
  const { language, setLanguage, study, setStudy, addNote } = useApp();
  const [topic, setTopic] = useState(study.topic);
  const [content, setContent] = useState(study.content);
  const [result, setResult] = useState<NotesResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  async function generate(e: FormEvent) {
    e.preventDefault();
    if (!content.trim()) {
      setError('Paste or type some study material first, or explain a topic and come back.');
      return;
    }
    setError('');
    setSaved(false);
    setLoading(true);
    try {
      const res = await api.notes({ topic: topic.trim(), content: content.trim(), language });
      setResult(res);
      setStudy({ topic: topic.trim(), content: content.trim() });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unexpected error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function save() {
    if (!result) return;
    addNote({
      topic: topic.trim() || 'Untitled notes',
      markdown: result.markdown,
      language,
      mode: result.mode,
    });
    setSaved(true);
  }

  return (
    <>
      <PageHeader
        title="Smart Notes"
        subtitle="Turn study material into short notes with definitions and a revision checklist."
        icon={<NotebookPen className="h-6 w-6" />}
      />

      <form onSubmit={generate} className="card space-y-5 p-5 sm:p-6">
        <div>
          <label htmlFor="notes-topic" className="label">
            Topic <span className="font-normal text-ink-500">(optional)</span>
          </label>
          <input
            id="notes-topic"
            className="input"
            maxLength={300}
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g. Photosynthesis"
          />
        </div>
        <div>
          <label htmlFor="notes-content" className="label">
            Study material
          </label>
          <textarea
            id="notes-content"
            className="input min-h-[180px] resize-y"
            maxLength={8000}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Paste text from your textbook, or use an explanation you just generated."
          />
          <p className="mt-1 text-xs text-ink-500">{content.length} / 8000 characters</p>
        </div>
        <LanguagePicker value={language} onChange={setLanguage} />
        <button type="submit" className="btn-primary" disabled={loading}>
          <Sparkles className="h-5 w-5" aria-hidden /> Create notes
        </button>
      </form>

      <div className="mt-6 space-y-4" aria-live="polite">
        {loading && <Spinner label="Writing your notes…" />}
        {error && <ErrorBox message={error} />}
        {result && !loading && (
          <article className="card animate-rise p-5 sm:p-7">
            <Markdown>{result.markdown}</Markdown>
            <div className="mt-6 flex flex-wrap gap-2 border-t border-cream-300/70 pt-5">
              <CopyButton text={result.markdown} label="Copy notes" />
              <button type="button" className="btn-secondary px-4 py-2 text-sm" onClick={save} disabled={saved}>
                {saved ? <Check className="h-4 w-4 text-teal-700" aria-hidden /> : <Save className="h-4 w-4" aria-hidden />}
                {saved ? 'Saved to My Learning' : 'Save notes'}
              </button>
            </div>
            <div className="mt-4">
              <AiNotice meta={result} />
            </div>
          </article>
        )}
      </div>
    </>
  );
}
