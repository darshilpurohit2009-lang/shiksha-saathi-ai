import { useEffect, useRef, useState, type DragEvent } from 'react';
import { Camera, ImageUp, ListChecks, NotebookPen, RefreshCw, Sparkles, Trash2 } from 'lucide-react';
import { api, ApiError } from '../lib/api';
import { useApp } from '../lib/app';
import { prepareImage, type PreparedImage } from '../lib/image';
import type { SnapResponse } from '../lib/types';
import { AiNotice, ErrorBox, LanguagePicker, Markdown, PageHeader, Spinner } from '../components/ui';

export function Snap() {
  const { language, setLanguage, status, setStudy, addTopic, go } = useApp();
  const [image, setImage] = useState<PreparedImage | null>(null);
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState<SnapResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [preparing, setPreparing] = useState(false);
  const [error, setError] = useState('');
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Free the preview object URL when it is replaced or the page closes.
  useEffect(() => {
    const url = image?.previewUrl;
    return () => {
      if (url) URL.revokeObjectURL(url);
    };
  }, [image]);

  async function choose(file: File | undefined) {
    if (!file) return;
    setError('');
    setResult(null);
    setPreparing(true);
    try {
      setImage(await prepareImage(file, status.maxImageMB));
    } catch (e) {
      setImage(null);
      setError(e instanceof Error ? e.message : 'Could not use that image.');
    } finally {
      setPreparing(false);
    }
  }

  function onDrop(e: DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragging(false);
    void choose(e.dataTransfer.files?.[0]);
  }

  async function analyze() {
    if (!image) return;
    setError('');
    setResult(null);
    setLoading(true);
    try {
      const res = await api.snap({
        imageBase64: image.base64,
        mimeType: image.mimeType,
        language,
        question: question.trim() || undefined,
      });
      setResult(res);
      if (!res.unclear) {
        setStudy({ topic: res.topic, content: res.markdown });
        addTopic(res.topic, 'snap', res.mode);
      }
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Unexpected error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setImage(null);
    setResult(null);
    setError('');
    if (inputRef.current) inputRef.current.value = '';
  }

  return (
    <>
      <PageHeader
        title="Snap & Learn"
        subtitle="Upload a clear photo of a textbook page or diagram. Gemma 4 will explain what it shows in simple language."
        icon={<Camera className="h-6 w-6" />}
      />

      <div className="card space-y-5 p-5 sm:p-6">
        {!image ? (
          <div
            role="button"
            tabIndex={0}
            aria-label="Upload a textbook image. Press Enter to choose a file."
            onClick={() => inputRef.current?.click()}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                inputRef.current?.click();
              }
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed px-6 py-14 text-center transition ${
              dragging ? 'border-teal-700 bg-teal-50' : 'border-cream-300 bg-cream-50 hover:border-teal-500'
            }`}
          >
            <ImageUp className="h-10 w-10 text-teal-700" aria-hidden />
            <p className="text-lg font-semibold">{preparing ? 'Preparing image…' : 'Drag a photo here or tap to upload'}</p>
            <p className="text-sm text-ink-600">JPEG, PNG or WebP · up to {status.maxImageMB} MB (large photos are shrunk automatically)</p>
          </div>
        ) : (
          <figure className="space-y-3">
            <img
              src={image.previewUrl}
              alt="Preview of the textbook image you selected"
              className="max-h-[420px] w-full rounded-xl border border-cream-300 bg-cream-50 object-contain"
            />
            <figcaption className="flex flex-wrap items-center justify-between gap-2 text-sm text-ink-600">
              <span>
                {image.sizeKB} KB{image.resized ? ' · resized for upload' : ''}
              </span>
              <button type="button" onClick={reset} className="btn-ghost text-sm">
                <Trash2 className="h-4 w-4" aria-hidden /> Remove
              </button>
            </figcaption>
          </figure>
        )}
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="sr-only"
          tabIndex={-1}
          aria-hidden
          onChange={(e) => void choose(e.target.files?.[0])}
        />

        <div>
          <label htmlFor="snap-q" className="label">
            Anything specific you are stuck on? <span className="font-normal text-ink-500">(optional)</span>
          </label>
          <input
            id="snap-q"
            className="input"
            maxLength={500}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="e.g. I don't understand the second diagram"
          />
        </div>

        <LanguagePicker value={language} onChange={setLanguage} />

        <button type="button" className="btn-primary" disabled={!image || loading} onClick={() => void analyze()}>
          <Sparkles className="h-5 w-5" aria-hidden /> Explain this page
        </button>
      </div>

      <div className="mt-6 space-y-4" aria-live="polite">
        {loading && <Spinner label="Reading your page…" />}
        {error && <ErrorBox message={error} onRetry={image ? () => void analyze() : undefined} />}

        {result?.unclear && !loading && (
          <div role="alert" className="notice notice-demo animate-rise">
            <p className="font-semibold">We could not read that image clearly</p>
            <div className="mt-1">
              <Markdown>{result.markdown}</Markdown>
            </div>
            <button type="button" onClick={reset} className="btn-secondary mt-3 px-4 py-2 text-sm">
              <RefreshCw className="h-4 w-4" aria-hidden /> Upload a clearer photo
            </button>
          </div>
        )}

        {result && !result.unclear && !loading && (
          <article className="card animate-rise p-5 sm:p-7">
            <p className="mb-2 text-sm font-semibold uppercase tracking-wide text-teal-800">Topic: {result.topic}</p>
            <Markdown>{result.markdown}</Markdown>
            <div className="mt-6 flex flex-wrap gap-2 border-t border-cream-300/70 pt-5">
              <button type="button" className="btn-secondary px-4 py-2 text-sm" onClick={() => go('notes')}>
                <NotebookPen className="h-4 w-4" aria-hidden /> Make notes
              </button>
              <button type="button" className="btn-secondary px-4 py-2 text-sm" onClick={() => go('quiz')}>
                <ListChecks className="h-4 w-4" aria-hidden /> Quiz me
              </button>
            </div>
            <div className="mt-4">
              <AiNotice meta={result} />
            </div>
          </article>
        )}
      </div>
    </>
  );
}
