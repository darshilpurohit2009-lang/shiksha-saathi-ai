import { useState } from 'react';
import { History, Trash2 } from 'lucide-react';
import { useApp } from '../lib/app';
import { computeStats, type Stats } from '../lib/stats';
import { CopyButton, EmptyState, Markdown, PageHeader, formatDate } from '../components/ui';
import { StatTiles } from '../components/StatTiles';

// Illustrative numbers only. Shown solely when the student turns on the preview, always labelled as sample data.
const SAMPLE_STATS: Stats = { topics: 6, notes: 4, quizzes: 3, averagePercent: 80 };

export function MyLearning() {
  const { data, deleteNote, clearAll } = useApp();
  const [sample, setSample] = useState(false);
  const [openNote, setOpenNote] = useState<string | null>(null);
  const stats = computeStats(data);
  const empty = data.topics.length + data.notes.length + data.quizzes.length === 0;

  return (
    <>
      <PageHeader
        title="My Learning"
        subtitle="Your topics, notes and quiz results. Everything is stored only in this browser (LocalStorage), never on a server."
        icon={<History className="h-6 w-6" />}
      />

      <section aria-labelledby="stats" className="mb-8">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <h2 id="stats" className="font-display text-xl font-bold">
            Progress
          </h2>
          <label className="flex cursor-pointer items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={sample}
              onChange={(e) => setSample(e.target.checked)}
              className="h-4 w-4 accent-teal-700"
            />
            Preview with sample data
          </label>
        </div>
        <StatTiles stats={sample ? SAMPLE_STATS : stats} sample={sample} />
        {empty && !sample && (
          <p className="mt-3 text-sm text-ink-600">
            These numbers are all zero because you have not studied anything yet. They only ever count what you do here.
          </p>
        )}
      </section>

      <section aria-labelledby="topics" className="mb-8">
        <h2 id="topics" className="mb-3 font-display text-xl font-bold">
          Recently studied topics
        </h2>
        {data.topics.length === 0 ? (
          <EmptyState title="No topics yet" hint="Use Explain a Topic or Snap & Learn to get started." />
        ) : (
          <ul className="card divide-y divide-cream-300/70">
            {data.topics.map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-3 px-5 py-3">
                <span className="font-semibold">{t.topic}</span>
                <span className="shrink-0 text-xs text-ink-500">
                  {t.source === 'snap' ? 'Photo' : 'Explained'} · {formatDate(t.createdAt)}
                  {t.mode === 'demo' && ' · demo'}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section aria-labelledby="notes" className="mb-8">
        <h2 id="notes" className="mb-3 font-display text-xl font-bold">
          Saved notes
        </h2>
        {data.notes.length === 0 ? (
          <EmptyState title="No saved notes" hint="Create notes in Smart Notes and press Save." />
        ) : (
          <ul className="space-y-3">
            {data.notes.map((n) => {
              const open = openNote === n.id;
              return (
                <li key={n.id} className="card p-4 sm:p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <button
                      type="button"
                      aria-expanded={open}
                      onClick={() => setOpenNote(open ? null : n.id)}
                      className="text-left"
                    >
                      <span className="block font-bold">{n.topic}</span>
                      <span className="text-xs text-ink-500">
                        {formatDate(n.createdAt)}
                        {n.mode === 'demo' && ' · demo sample'}
                      </span>
                    </button>
                    <div className="flex gap-2">
                      <CopyButton text={n.markdown} />
                      <button
                        type="button"
                        className="btn-secondary px-3 py-2 text-sm"
                        aria-label={`Delete notes on ${n.topic}`}
                        onClick={() => deleteNote(n.id)}
                      >
                        <Trash2 className="h-4 w-4" aria-hidden />
                      </button>
                    </div>
                  </div>
                  {open && (
                    <div className="mt-4 border-t border-cream-300/70 pt-4">
                      <Markdown>{n.markdown}</Markdown>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section aria-labelledby="quizzes" className="mb-8">
        <h2 id="quizzes" className="mb-3 font-display text-xl font-bold">
          Quiz results
        </h2>
        {data.quizzes.length === 0 ? (
          <EmptyState title="No quizzes yet" hint="Take a quiz in Quiz Me and your score will appear here." />
        ) : (
          <ul className="card divide-y divide-cream-300/70">
            {data.quizzes.map((q) => (
              <li key={q.id} className="flex items-center justify-between gap-3 px-5 py-3">
                <span>
                  <span className="block font-semibold">{q.topic}</span>
                  <span className="text-xs text-ink-500">
                    {formatDate(q.createdAt)}
                    {q.mode === 'demo' && ' · demo questions'}
                  </span>
                </span>
                <span className="font-display text-xl font-bold text-teal-800">
                  {q.score}/{q.total}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {!empty && (
        <button
          type="button"
          className="btn-ghost text-red-800 hover:bg-red-50"
          onClick={() => {
            if (window.confirm('Delete all saved topics, notes and quiz results from this browser?')) clearAll();
          }}
        >
          <Trash2 className="h-4 w-4" aria-hidden /> Clear all my data
        </button>
      )}
    </>
  );
}
