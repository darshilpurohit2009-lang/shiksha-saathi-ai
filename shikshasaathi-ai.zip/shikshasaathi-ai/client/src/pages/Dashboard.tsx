import { ArrowRight, Camera, Lightbulb, ListChecks, NotebookPen } from 'lucide-react';
import { useApp } from '../lib/app';
import { computeStats } from '../lib/stats';
import { EmptyState, ModeBadge, PageHeader, formatDate } from '../components/ui';
import { StatTiles } from '../components/StatTiles';
import type { View } from '../lib/types';

const ACTIONS: Array<{ view: View; title: string; text: string; icon: typeof Camera }> = [
  { view: 'snap', title: 'Snap & Learn', text: 'Upload a textbook photo', icon: Camera },
  { view: 'explain', title: 'Explain a Topic', text: 'Ask any question', icon: Lightbulb },
  { view: 'notes', title: 'Smart Notes', text: 'Make revision notes', icon: NotebookPen },
  { view: 'quiz', title: 'Quiz Me', text: 'Test your understanding', icon: ListChecks },
];

export function Dashboard() {
  const { go, status, data, setStudy } = useApp();
  const stats = computeStats(data);

  return (
    <>
      <PageHeader title="Welcome back" subtitle="Pick up where you left off, or start something new." />

      <section
        aria-label="AI mode"
        className={`card mb-6 flex flex-wrap items-center justify-between gap-3 p-5 ${
          status.state === 'live' ? 'bg-gradient-to-r from-teal-50 to-white' : ''
        }`}
      >
        <div>
          <p className="font-semibold text-ink-900">
            {status.state === 'live' && 'Live AI mode is on'}
            {status.state === 'demo' && 'You are in demo mode'}
            {status.state === 'offline' && 'The server is not reachable'}
            {status.state === 'loading' && 'Checking the server…'}
          </p>
          <p className="text-sm text-ink-600">
            {status.state === 'live' && 'Answers come from Google Gemma 4 through the server.'}
            {status.state === 'demo' && 'You will see labelled sample outputs. Add a GEMINI_API_KEY on the server for live answers.'}
            {status.state === 'offline' && 'Start the backend with npm run dev, then refresh this page.'}
          </p>
        </div>
        <ModeBadge status={status} />
      </section>

      <section aria-labelledby="quick" className="mb-8">
        <h2 id="quick" className="mb-3 font-display text-xl font-bold">
          Start learning
        </h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {ACTIONS.map(({ view, title, text, icon: Icon }, i) => (
            <button
              key={view}
              type="button"
              onClick={() => go(view)}
              style={{ animationDelay: `${i * 70}ms` }}
              className="card group flex animate-rise items-center gap-4 p-5 text-left transition hover:-translate-y-0.5 hover:border-teal-300"
            >
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-teal-700/10 text-teal-800">
                <Icon className="h-6 w-6" aria-hidden />
              </span>
              <span className="flex-1">
                <span className="block font-bold">{title}</span>
                <span className="text-sm text-ink-600">{text}</span>
              </span>
              <ArrowRight className="h-5 w-5 text-ink-500 transition group-hover:translate-x-1" aria-hidden />
            </button>
          ))}
        </div>
      </section>

      <section aria-labelledby="progress" className="mb-8">
        <h2 id="progress" className="mb-3 font-display text-xl font-bold">
          Your progress <span className="text-sm font-normal text-ink-500">(saved on this device)</span>
        </h2>
        <StatTiles stats={stats} />
      </section>

      <section aria-labelledby="recent">
        <h2 id="recent" className="mb-3 font-display text-xl font-bold">
          Recently studied
        </h2>
        {data.topics.length === 0 ? (
          <EmptyState title="Nothing here yet" hint="Topics you explain or snap will appear here." />
        ) : (
          <ul className="card divide-y divide-cream-300/70">
            {data.topics.slice(0, 5).map((t) => (
              <li key={t.id}>
                <button
                  type="button"
                  onClick={() => {
                    setStudy({ topic: t.topic, content: '' });
                    go('explain');
                  }}
                  className="flex w-full items-center justify-between gap-3 px-5 py-3.5 text-left hover:bg-cream-50"
                >
                  <span>
                    <span className="block font-semibold">{t.topic}</span>
                    <span className="text-xs text-ink-500">
                      {t.source === 'snap' ? 'From a photo' : 'Explained'} · {formatDate(t.createdAt)}
                      {t.mode === 'demo' && ' · demo'}
                    </span>
                  </span>
                  <ArrowRight className="h-4 w-4 shrink-0 text-ink-500" aria-hidden />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
