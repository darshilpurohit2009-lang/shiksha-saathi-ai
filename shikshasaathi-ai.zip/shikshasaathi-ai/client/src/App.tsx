import { AppProvider, useApp } from './lib/app';
import { Layout } from './components/Layout';
import { Landing } from './pages/Landing';
import { Dashboard } from './pages/Dashboard';
import { Snap } from './pages/Snap';
import { Explain } from './pages/Explain';
import { Notes } from './pages/Notes';
import { Quiz } from './pages/Quiz';
import { MyLearning } from './pages/MyLearning';

function Router() {
  const { view } = useApp();
  if (view === 'landing') return <Landing />;
  return (
    <Layout>
      {view === 'dashboard' && <Dashboard />}
      {view === 'snap' && <Snap />}
      {view === 'explain' && <Explain />}
      {view === 'notes' && <Notes />}
      {view === 'quiz' && <Quiz />}
      {view === 'learning' && <MyLearning />}
    </Layout>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Router />
    </AppProvider>
  );
}
