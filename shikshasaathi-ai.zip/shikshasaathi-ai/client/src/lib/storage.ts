import type { Language, LearningData } from './types';

const KEY = 'shikshasaathi.learning.v1';
const LANG_KEY = 'shikshasaathi.language.v1';

export const emptyData = (): LearningData => ({ notes: [], quizzes: [], topics: [] });

// LocalStorage can be unavailable (private mode, blocked cookies), so every access is guarded.
export function loadData(): LearningData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptyData();
    const parsed = JSON.parse(raw) as Partial<LearningData>;
    return {
      notes: Array.isArray(parsed.notes) ? parsed.notes : [],
      quizzes: Array.isArray(parsed.quizzes) ? parsed.quizzes : [],
      topics: Array.isArray(parsed.topics) ? parsed.topics : [],
    };
  } catch {
    return emptyData();
  }
}

export function saveData(data: LearningData): boolean {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
}

export function loadLanguage(): Language {
  try {
    const v = localStorage.getItem(LANG_KEY);
    if (v === 'english' || v === 'hindi' || v === 'hinglish') return v;
  } catch {
    /* ignore */
  }
  return 'english';
}

export function saveLanguage(lang: Language): void {
  try {
    localStorage.setItem(LANG_KEY, lang);
  } catch {
    /* ignore */
  }
}

export const newId = (): string =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
