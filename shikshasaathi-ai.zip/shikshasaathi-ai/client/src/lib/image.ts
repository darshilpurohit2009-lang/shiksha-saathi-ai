const ALLOWED = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_RAW_BYTES = 15 * 1024 * 1024;

export interface PreparedImage {
  base64: string;
  mimeType: string;
  previewUrl: string;
  sizeKB: number;
  resized: boolean;
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] ?? '');
    reader.onerror = () => reject(new Error('Could not read that image.'));
    reader.readAsDataURL(blob);
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', quality));
}

async function shrink(file: File, maxSide: number, quality: number): Promise<Blob | null> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close?.();
  return canvasToBlob(canvas, quality);
}

/**
 * Validates the chosen file and, if it is large (typical for phone photos),
 * downsizes it so it fits the server's size limit and uploads quickly.
 */
export async function prepareImage(file: File, maxMB: number): Promise<PreparedImage> {
  if (!ALLOWED.includes(file.type)) throw new Error('Please choose a JPEG, PNG or WebP image.');
  if (file.size > MAX_RAW_BYTES) throw new Error('That photo is over 15 MB. Please choose a smaller one.');

  const maxBytes = maxMB * 1024 * 1024;
  let blob: Blob = file;
  let mimeType = file.type;
  let resized = false;

  if (file.size > maxBytes * 0.5) {
    const attempts: Array<[number, number]> = [
      [1800, 0.85],
      [1400, 0.75],
      [1000, 0.7],
    ];
    for (const [side, q] of attempts) {
      try {
        const out = await shrink(file, side, q);
        if (out && out.size <= maxBytes) {
          blob = out;
          mimeType = 'image/jpeg';
          resized = true;
          break;
        }
      } catch {
        throw new Error('Could not process that image. Try a different photo.');
      }
    }
  }

  if (blob.size > maxBytes) {
    throw new Error(`Image is still larger than ${maxMB} MB. Please crop it or choose a smaller photo.`);
  }

  return {
    base64: await blobToBase64(blob),
    mimeType,
    previewUrl: URL.createObjectURL(blob),
    sizeKB: Math.round(blob.size / 1024),
    resized,
  };
}
