import type { LearningData } from './types';

export interface Stats {
  topics: number;
  notes: number;
  quizzes: number;
  averagePercent: number | null;
}

/** Computed only from what the student has actually done on this device. */
export function computeStats(d: LearningData): Stats {
  const totalScore = d.quizzes.reduce((s, q) => s + q.score, 0);
  const totalQ = d.quizzes.reduce((s, q) => s + q.total, 0);
  return {
    topics: d.topics.length,
    notes: d.notes.length,
    quizzes: d.quizzes.length,
    averagePercent: totalQ > 0 ? Math.round((totalScore / totalQ) * 100) : null,
  };
}
