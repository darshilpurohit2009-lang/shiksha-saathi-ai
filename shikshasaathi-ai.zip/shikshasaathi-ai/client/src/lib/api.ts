import type {
  ExplainResponse,
  Language,
  NotesResponse,
  QuizResponse,
  SnapResponse,
  Status,
} from './types';

export class ApiError extends Error {
  code: string;
  status: number;
  constructor(message: string, code: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
  }
}

async function request<T>(path: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      method: body === undefined ? 'GET' : 'POST',
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(
      'Cannot reach the ShikshaSaathi server. Make sure it is running (npm run dev) and check your internet connection.',
      'NETWORK',
      0
    );
  }

  let data: { ok?: boolean; error?: string; code?: string } | null = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON response */
  }

  if (!res.ok || !data || data.ok === false) {
    throw new ApiError(
      data?.error ?? `The server returned an unexpected response (${res.status}).`,
      data?.code ?? 'ERROR',
      res.status
    );
  }
  return data as T;
}

export async function fetchStatus(): Promise<Status> {
  try {
    const d = await request<{ mode: 'live' | 'demo'; model: string | null; maxImageMB: number; reason: string | null }>(
      '/api/status'
    );
    return { state: d.mode, model: d.model, maxImageMB: d.maxImageMB, reason: d.reason };
  } catch {
    return { state: 'offline', model: null, maxImageMB: 4, reason: 'Server unreachable' };
  }
}

export const api = {
  explain: (p: { topic: string; language: Language; simpler?: boolean; previous?: string }) =>
    request<ExplainResponse>('/api/explain', p),
  snap: (p: { imageBase64: string; mimeType: string; language: Language; question?: string }) =>
    request<SnapResponse>('/api/snap', p),
  notes: (p: { topic: string; content: string; language: Language }) => request<NotesResponse>('/api/notes', p),
  quiz: (p: { topic: string; content?: string; language: Language }) => request<QuizResponse>('/api/quiz', p),
};
