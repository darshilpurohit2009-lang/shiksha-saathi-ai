export type Language = 'english' | 'hindi' | 'hinglish';
export type Mode = 'live' | 'demo';
export type View = 'landing' | 'dashboard' | 'snap' | 'explain' | 'notes' | 'quiz' | 'learning';

/** Present on every successful AI response. `aiGenerated` is true only after a real Gemma call succeeded. */
export interface ApiMeta {
  mode: Mode;
  aiGenerated: boolean;
  model: string | null;
}

export interface Status {
  state: 'loading' | 'live' | 'demo' | 'offline';
  model: string | null;
  maxImageMB: number;
  reason: string | null;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export type ExplainResponse = ApiMeta & { topic: string; markdown: string };
export type SnapResponse = ApiMeta & { unclear: boolean; topic: string; markdown: string };
export type NotesResponse = ApiMeta & { topic: string; markdown: string };
export type QuizResponse = ApiMeta & { topic: string; questions: QuizQuestion[]; note?: string };

export interface SavedNote {
  id: string;
  topic: string;
  markdown: string;
  language: Language;
  mode: Mode;
  createdAt: string;
}

export interface QuizResult {
  id: string;
  topic: string;
  score: number;
  total: number;
  mode: Mode;
  createdAt: string;
}

export interface RecentTopic {
  id: string;
  topic: string;
  source: 'explain' | 'snap';
  mode: Mode;
  createdAt: string;
}

export interface LearningData {
  notes: SavedNote[];
  quizzes: QuizResult[];
  topics: RecentTopic[];
}

export const LANGUAGE_LABELS: Record<Language, string> = {
  english: 'Simple English',
  hindi: 'हिन्दी',
  hinglish: 'Hinglish',
};
