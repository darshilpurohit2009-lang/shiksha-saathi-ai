import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { fetchStatus } from './api';
import { loadData, loadLanguage, newId, saveData, saveLanguage, emptyData } from './storage';
import type { Language, LearningData, Mode, QuizResult, RecentTopic, SavedNote, Status, View } from './types';

interface Study {
  topic: string;
  content: string;
}

interface AppState {
  view: View;
  go: (v: View) => void;
  status: Status;
  language: Language;
  setLanguage: (l: Language) => void;
  study: Study;
  setStudy: (s: Study) => void;
  data: LearningData;
  addTopic: (topic: string, source: RecentTopic['source'], mode: Mode) => void;
  addNote: (note: Omit<SavedNote, 'id' | 'createdAt'>) => void;
  addQuiz: (q: Omit<QuizResult, 'id' | 'createdAt'>) => void;
  deleteNote: (id: string) => void;
  clearAll: () => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [view, setView] = useState<View>('landing');
  const [status, setStatus] = useState<Status>({ state: 'loading', model: null, maxImageMB: 4, reason: null });
  const [language, setLanguageState] = useState<Language>(loadLanguage);
  const [study, setStudy] = useState<Study>({ topic: '', content: '' });
  const [data, setData] = useState<LearningData>(loadData);

  useEffect(() => {
    let alive = true;
    fetchStatus().then((s) => alive && setStatus(s));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    saveData(data);
  }, [data]);

  const go = useCallback((v: View) => {
    setView(v);
    window.scrollTo({ top: 0 });
    // Move keyboard / screen-reader focus to the new page.
    requestAnimationFrame(() => document.getElementById('main')?.focus());
  }, []);

  const setLanguage = useCallback((l: Language) => {
    setLanguageState(l);
    saveLanguage(l);
  }, []);

  const addTopic = useCallback((topic: string, source: RecentTopic['source'], mode: Mode) => {
    const t = topic.trim();
    if (!t) return;
    setData((d) => ({
      ...d,
      topics: [
        { id: newId(), topic: t, source, mode, createdAt: new Date().toISOString() },
        ...d.topics.filter((x) => x.topic.toLowerCase() !== t.toLowerCase()),
      ].slice(0, 30),
    }));
  }, []);

  const addNote = useCallback((note: Omit<SavedNote, 'id' | 'createdAt'>) => {
    setData((d) => ({ ...d, notes: [{ ...note, id: newId(), createdAt: new Date().toISOString() }, ...d.notes] }));
  }, []);

  const addQuiz = useCallback((q: Omit<QuizResult, 'id' | 'createdAt'>) => {
    setData((d) => ({ ...d, quizzes: [{ ...q, id: newId(), createdAt: new Date().toISOString() }, ...d.quizzes] }));
  }, []);

  const deleteNote = useCallback((id: string) => {
    setData((d) => ({ ...d, notes: d.notes.filter((n) => n.id !== id) }));
  }, []);

  const clearAll = useCallback(() => setData(emptyData()), []);

  const value = useMemo<AppState>(
    () => ({ view, go, status, language, setLanguage, study, setStudy, data, addTopic, addNote, addQuiz, deleteNote, clearAll }),
    [view, go, status, language, setLanguage, study, data, addTopic, addNote, addQuiz, deleteNote, clearAll]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp must be used inside AppProvider');
  return v;
}
