import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../src/config.js';
import { createApp } from '../src/app.js';
import { createGemmaService, extractJson, validateQuiz, mapSdkError } from '../src/gemma.js';

const PNG_1X1 =
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

const goodQuizJson = JSON.stringify({
  questions: Array.from({ length: 5 }, (_, i) => ({
    question: `Q${i + 1}?`,
    options: ['a', 'b', 'c', 'd'],
    correctIndex: i % 4,
    explanation: 'because',
  })),
});

function fakeClient(reply, calls = []) {
  return {
    models: {
      generateContent: async (args) => {
        calls.push(args);
        const text = typeof reply === 'function' ? reply(args) : reply;
        if (text instanceof Error) throw text;
        return { text };
      },
    },
    files: { upload: async () => ({ uri: 'files/abc', mimeType: 'image/png' }) },
  };
}

async function start(app) {
  const server = await new Promise((resolve) => {
    const s = app.listen(0, () => resolve(s));
  });
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = (p, body) =>
    fetch(base + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }).then(
      async (r) => ({ status: r.status, json: await r.json() })
    );
  const get = (p) => fetch(base + p).then(async (r) => ({ status: r.status, json: await r.json() }));
  return { server, post, get };
}

// ---------- config ----------
test('config: placeholder key counts as unset (demo mode)', () => {
  const c = loadConfig({ GEMINI_API_KEY: 'your_api_key_here' });
  assert.equal(c.liveConfigured, false);
});

test('config: refuses non-Gemma-4 models', () => {
  assert.throws(() => loadConfig({ GEMINI_API_KEY: 'k', GEMMA_MODEL: 'gemini-2.5-flash' }), /Gemma 4/);
});

test('config: defaults to gemma-4-26b-a4b-it', () => {
  assert.equal(loadConfig({ GEMINI_API_KEY: 'k' }).model, 'gemma-4-26b-a4b-it');
});

// ---------- helpers ----------
test('extractJson handles fences and prose', () => {
  assert.deepEqual(extractJson('Sure!\n```json\n{"a":1}\n```'), { a: 1 });
});

test('validateQuiz rejects wrong counts and bad indexes', () => {
  assert.throws(() => validateQuiz({ questions: [] }));
  const bad = JSON.parse(goodQuizJson);
  bad.questions[0].correctIndex = 9;
  assert.throws(() => validateQuiz(bad));
  assert.equal(validateQuiz(JSON.parse(goodQuizJson)).length, 5);
});

test('mapSdkError maps rate limits and network errors', () => {
  assert.equal(mapSdkError({ status: 429, message: 'x' }).code, 'RATE_LIMITED');
  assert.equal(mapSdkError(new Error('fetch failed')).code, 'NETWORK');
  assert.equal(mapSdkError({ status: 403, message: 'x' }).code, 'AUTH_FAILED');
});

// ---------- demo mode ----------
let demoCtx;
before(async () => {
  const config = loadConfig({});
  demoCtx = await start(createApp({ config, service: null }));
});
after(() => demoCtx.server.close());

test('demo: status reports demo and no model', async () => {
  const { json } = await demoCtx.get('/api/status');
  assert.equal(json.mode, 'demo');
  assert.equal(json.model, null);
});

test('demo: explain is labelled and never claims AI or Gemma', async () => {
  const { status, json } = await demoCtx.post('/api/explain', { topic: 'Photosynthesis', language: 'english' });
  assert.equal(status, 200);
  assert.equal(json.mode, 'demo');
  assert.equal(json.aiGenerated, false);
  assert.equal(json.model, null);
  assert.match(json.markdown, /DEMO SAMPLE/);
});

test('demo: quiz returns 5 questions', async () => {
  const { json } = await demoCtx.post('/api/quiz', { topic: 'x', language: 'english' });
  assert.equal(json.questions.length, 5);
});

test('demo: gemma health check is unavailable', async () => {
  const { status } = await demoCtx.get('/api/health/gemma');
  assert.equal(status, 503);
});

// ---------- validation ----------
test('validation: empty topic, bad language, bad image', async () => {
  assert.equal((await demoCtx.post('/api/explain', { topic: '   ', language: 'english' })).status, 400);
  assert.equal((await demoCtx.post('/api/explain', { topic: 'x', language: 'french' })).status, 400);
  assert.equal(
    (await demoCtx.post('/api/snap', { imageBase64: PNG_1X1, mimeType: 'image/gif', language: 'english' })).status,
    400
  );
  // declared PNG but content is not an image
  const notImg = Buffer.from('hello world, definitely not an image').toString('base64');
  assert.equal(
    (await demoCtx.post('/api/snap', { imageBase64: notImg, mimeType: 'image/png', language: 'english' })).status,
    400
  );
});

test('validation: oversized image is rejected', async () => {
  const config = { ...loadConfig({}), maxImageBytes: 10 };
  const ctx = await start(createApp({ config, service: null }));
  const r = await ctx.post('/api/snap', { imageBase64: PNG_1X1, mimeType: 'image/png', language: 'english' });
  ctx.server.close();
  assert.equal(r.status, 400);
  assert.match(r.json.error, /too large/i);
});

test('demo: valid image is accepted but clearly not analysed', async () => {
  const { status, json } = await demoCtx.post('/api/snap', {
    imageBase64: PNG_1X1,
    mimeType: 'image/png',
    language: 'hinglish',
  });
  assert.equal(status, 200);
  assert.equal(json.aiGenerated, false);
  assert.match(json.markdown, /DEMO SAMPLE|DEMO/);
});

// ---------- live mode (fake SDK client, no network) ----------
test('live: explain marks response as Gemma only after a successful call', async () => {
  const calls = [];
  const config = loadConfig({ GEMINI_API_KEY: 'test-key' });
  const service = createGemmaService({ ...config, client: fakeClient('## In one line\nHi', calls) });
  const ctx = await start(createApp({ config, service }));
  const { status, json } = await ctx.post('/api/explain', { topic: 'Gravity', language: 'hindi' });
  ctx.server.close();
  assert.equal(status, 200);
  assert.equal(json.mode, 'live');
  assert.equal(json.aiGenerated, true);
  assert.equal(json.model, 'gemma-4-26b-a4b-it');
  assert.equal(calls[0].model, 'gemma-4-26b-a4b-it');
  assert.match(calls[0].contents, /Devanagari/);
});

test('live: image request sends image part before text, to the Gemma model', async () => {
  const calls = [];
  const config = loadConfig({ GEMINI_API_KEY: 'test-key' });
  const service = createGemmaService({
    ...config,
    client: fakeClient('TOPIC: Photosynthesis\n## What this page is about\nPlants', calls),
  });
  const ctx = await start(createApp({ config, service }));
  const { json } = await ctx.post('/api/snap', { imageBase64: PNG_1X1, mimeType: 'image/png', language: 'english' });
  ctx.server.close();
  assert.equal(json.topic, 'Photosynthesis');
  assert.equal(json.unclear, false);
  const parts = calls[0].contents[0].parts;
  assert.ok(parts[0].inlineData, 'image first');
  assert.ok(parts[1].text, 'text second');
  assert.match(calls[0].model, /^gemma-4/);
});

test('live: unclear image is reported, not invented', async () => {
  const config = loadConfig({ GEMINI_API_KEY: 'test-key' });
  const service = createGemmaService({
    ...config,
    client: fakeClient('UNCLEAR_IMAGE: The photo is too blurry. Please upload a clearer one.'),
  });
  const ctx = await start(createApp({ config, service }));
  const { json } = await ctx.post('/api/snap', { imageBase64: PNG_1X1, mimeType: 'image/png', language: 'english' });
  ctx.server.close();
  assert.equal(json.unclear, true);
  assert.match(json.markdown, /clearer/);
});

test('live: quiz retries once on malformed JSON then succeeds', async () => {
  let n = 0;
  const config = loadConfig({ GEMINI_API_KEY: 'test-key' });
  const service = createGemmaService({ ...config, client: fakeClient(() => (n++ === 0 ? 'not json' : goodQuizJson)) });
  const ctx = await start(createApp({ config, service }));
  const { status, json } = await ctx.post('/api/quiz', { topic: 'Atoms', language: 'english' });
  ctx.server.close();
  assert.equal(status, 200);
  assert.equal(json.questions.length, 5);
  assert.equal(n, 2);
});

test('live: rate limit from Gemma surfaces as 429 and never falls back to demo', async () => {
  const config = loadConfig({ GEMINI_API_KEY: 'test-key' });
  const err = Object.assign(new Error('RESOURCE_EXHAUSTED'), { status: 429 });
  const service = createGemmaService({ ...config, client: fakeClient(err) });
  const ctx = await start(createApp({ config, service }));
  const { status, json } = await ctx.post('/api/explain', { topic: 'x', language: 'english' });
  ctx.server.close();
  assert.equal(status, 429);
  assert.equal(json.ok, false);
  assert.equal(json.code, 'RATE_LIMITED');
  assert.equal(json.aiGenerated, undefined);
});

test('live: network failure surfaces as 503', async () => {
  const config = loadConfig({ GEMINI_API_KEY: 'test-key' });
  const service = createGemmaService({ ...config, client: fakeClient(new Error('fetch failed')) });
  const ctx = await start(createApp({ config, service }));
  const { status, json } = await ctx.post('/api/notes', { content: 'abc', language: 'english' });
  ctx.server.close();
  assert.equal(status, 503);
  assert.equal(json.code, 'NETWORK');
});

test('API key never appears in any response', async () => {
  const config = loadConfig({ GEMINI_API_KEY: 'SECRET-KEY-123' });
  const service = createGemmaService({ ...config, client: fakeClient('ok') });
  const ctx = await start(createApp({ config, service }));
  const a = await ctx.get('/api/status');
  const b = await ctx.post('/api/explain', { topic: 'x', language: 'english' });
  ctx.server.close();
  assert.ok(!JSON.stringify([a, b]).includes('SECRET-KEY-123'));
});
