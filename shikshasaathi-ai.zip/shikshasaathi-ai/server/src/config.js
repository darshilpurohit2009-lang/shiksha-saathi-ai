// Reads configuration from environment variables (server-side only).
// The API key never leaves the server and is never sent to the browser.

export const DEFAULT_MODEL = 'gemma-4-26b-a4b-it';

// Gemma 4 models documented for the Gemini API (verified against
// https://ai.google.dev/gemma/docs/core/gemma_on_gemini_api).
export const VERIFIED_MODELS = ['gemma-4-26b-a4b-it', 'gemma-4-31b-it'];

const PLACEHOLDER_KEYS = new Set(['', 'your_api_key_here', 'changeme', 'your-api-key']);

export function loadConfig(env = process.env) {
  const rawKey = (env.GEMINI_API_KEY || '').trim();
  const apiKey = PLACEHOLDER_KEYS.has(rawKey.toLowerCase()) ? '' : rawKey;
  const model = (env.GEMMA_MODEL || DEFAULT_MODEL).trim();

  // Never silently substitute another family of model.
  if (!/^gemma-4/i.test(model)) {
    throw new Error(
      `GEMMA_MODEL must be a Gemma 4 model (got "${model}"). Supported: ${VERIFIED_MODELS.join(', ')}.`
    );
  }

  const forceDemo = String(env.FORCE_DEMO_MODE || '').toLowerCase() === 'true';
  const imageMode = (env.GEMMA_IMAGE_MODE || 'inline').toLowerCase() === 'files' ? 'files' : 'inline';

  return {
    port: Number(env.PORT) || 8787,
    apiKey,
    model,
    imageMode,
    liveConfigured: Boolean(apiKey) && !forceDemo,
    forceDemo,
    maxImageBytes: Number(env.MAX_IMAGE_MB || 4) * 1024 * 1024,
    requestTimeoutMs: Number(env.REQUEST_TIMEOUT_MS) || 90_000,
    modelIsVerified: VERIFIED_MODELS.includes(model),
  };
}
