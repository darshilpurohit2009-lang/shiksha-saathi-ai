// Run with: npm run test:gemma   (from repo root)
// Makes one real text call and one real image call to Gemma 4 to verify your setup.
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { loadConfig } from '../config.js';
import { createGemmaService } from '../gemma.js';

const here = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(here, '..', '..', '..', '.env') });

const config = loadConfig();
if (!config.liveConfigured) {
  console.error('No GEMINI_API_KEY found. Copy .env.example to .env and add your key, then retry.');
  process.exit(1);
}

const svc = createGemmaService({
  apiKey: config.apiKey,
  model: config.model,
  imageMode: config.imageMode,
  timeoutMs: config.requestTimeoutMs,
});

// A tiny valid 1x1 PNG, used to check that image input is accepted by the model.
const PNG_1X1 =
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

let failed = false;

try {
  console.log(`Model: ${config.model}`);
  const ping = await svc.ping();
  console.log(`TEXT  ok (${ping.latencyMs} ms): ${ping.reply.slice(0, 80)}`);
} catch (err) {
  failed = true;
  console.error(`TEXT  FAILED [${err.code}]: ${err.message}`);
}

try {
  const buffer = Buffer.from(PNG_1X1, 'base64');
  const out = await svc.snap({
    image: { buffer, base64: PNG_1X1, mimeType: 'image/png' },
    language: 'english',
    question: '',
  });
  console.log(`IMAGE ok (image input accepted). unclear=${out.unclear}`);
  console.log(`      reply: ${out.markdown.slice(0, 100).replace(/\n/g, ' ')}`);
} catch (err) {
  failed = true;
  console.error(`IMAGE FAILED [${err.code}]: ${err.message}`);
  console.error('      If inline images are rejected, try GEMMA_IMAGE_MODE=files in .env.');
}

process.exit(failed ? 1 : 0);
