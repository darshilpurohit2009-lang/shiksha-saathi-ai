import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { loadConfig } from './config.js';
import { createGemmaService } from './gemma.js';
import { createApp } from './app.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..', '..');
dotenv.config({ path: path.join(root, '.env') });

const config = loadConfig();
const service = config.liveConfigured
  ? createGemmaService({
      apiKey: config.apiKey,
      model: config.model,
      imageMode: config.imageMode,
      timeoutMs: config.requestTimeoutMs,
    })
  : null;

const app = createApp({ config, service, clientDist: path.join(root, 'client', 'dist') });

app.listen(config.port, () => {
  console.log(`ShikshaSaathi AI server on http://localhost:${config.port}`);
  if (config.liveConfigured) {
    console.log(`Mode: LIVE - Gemma 4 model "${config.model}" (image input: ${config.imageMode})`);
    if (!config.modelIsVerified) console.warn('Warning: this model is not in the verified Gemma 4 list.');
  } else {
    console.log(`Mode: DEMO - ${config.forceDemo ? 'FORCE_DEMO_MODE is on' : 'no GEMINI_API_KEY set'}. Sample outputs only.`);
  }
});
