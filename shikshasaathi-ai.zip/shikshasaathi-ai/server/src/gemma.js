import { GoogleGenAI, createPartFromUri } from '@google/genai';
import {
  SYSTEM_INSTRUCTION,
  explainPrompt,
  snapPrompt,
  notesPrompt,
  quizPrompt,
  PING_PROMPT,
} from './prompts.js';

export class GemmaError extends Error {
  constructor(message, { status = 502, code = 'GEMMA_ERROR' } = {}) {
    super(message);
    this.name = 'GemmaError';
    this.status = status;
    this.code = code;
  }
}

// Turns raw SDK / network failures into friendly, accurate errors.
export function mapSdkError(err) {
  if (err instanceof GemmaError) return err;
  const status = Number(err?.status ?? err?.code ?? err?.error?.code) || 0;
  const msg = String(err?.message || err || '');

  if (status === 429 || /RESOURCE_EXHAUSTED|rate limit|quota/i.test(msg)) {
    return new GemmaError(
      'Gemma is receiving too many requests right now (rate limit or quota reached). Please wait a minute and try again.',
      { status: 429, code: 'RATE_LIMITED' }
    );
  }
  if (status === 401 || status === 403 || /API key|PERMISSION_DENIED|UNAUTHENTICATED/i.test(msg)) {
    return new GemmaError(
      'The server could not authenticate with the Gemini API. The API key may be missing, invalid or restricted.',
      { status: 502, code: 'AUTH_FAILED' }
    );
  }
  if (status === 404 || /models\/.+ is not found|NOT_FOUND/i.test(msg)) {
    return new GemmaError(
      'The configured Gemma 4 model was not found on the Gemini API. Check GEMMA_MODEL in your .env file.',
      { status: 502, code: 'MODEL_NOT_FOUND' }
    );
  }
  if (err?.code === 'TIMEOUT') {
    return new GemmaError('Gemma took too long to respond. Please try again.', { status: 504, code: 'TIMEOUT' });
  }
  if (/fetch failed|ENOTFOUND|ECONNRESET|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN|network|socket/i.test(msg)) {
    return new GemmaError('Could not reach the Gemini API. Please check the server\'s internet connection.', {
      status: 503,
      code: 'NETWORK',
    });
  }
  if (status === 400) {
    return new GemmaError('Gemma could not process that request. Try a shorter question or a different image.', {
      status: 502,
      code: 'BAD_REQUEST',
    });
  }
  return new GemmaError('Gemma returned an unexpected error. Please try again.', { status: 502, code: 'GEMMA_ERROR' });
}

function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(Object.assign(new Error('timeout'), { code: 'TIMEOUT' })), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

// Pulls a JSON object out of model text (handles ```json fences and stray prose).
export function extractJson(text) {
  const cleaned = String(text || '')
    .replace(/```(?:json)?/gi, '')
    .trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start === -1 || end === -1 || end <= start) throw new Error('No JSON object found');
  return JSON.parse(cleaned.slice(start, end + 1));
}

export function validateQuiz(data) {
  const qs = data?.questions;
  if (!Array.isArray(qs) || qs.length !== 5) throw new Error('Quiz must have exactly 5 questions');
  return qs.map((q, i) => {
    const options = Array.isArray(q.options) ? q.options.map((o) => String(o).trim()) : [];
    const correctIndex = Number(q.correctIndex);
    if (!q.question || options.length !== 4 || options.some((o) => !o)) {
      throw new Error(`Question ${i + 1} is malformed`);
    }
    if (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex > 3) {
      throw new Error(`Question ${i + 1} has an invalid correctIndex`);
    }
    return {
      id: `q${i + 1}`,
      question: String(q.question).trim(),
      options,
      correctIndex,
      explanation: String(q.explanation || '').trim(),
    };
  });
}

/**
 * Thin wrapper around the official @google/genai SDK that always targets the
 * configured Gemma 4 model. It never falls back to another model.
 */
export function createGemmaService({ apiKey, model, imageMode = 'inline', timeoutMs = 90_000, client }) {
  const ai = client ?? new GoogleGenAI({ apiKey });

  async function generate({ prompt, image }) {
    try {
      let contents = prompt;
      if (image) {
        let imagePart;
        if (imageMode === 'files') {
          const uploaded = await ai.files.upload({
            file: new Blob([image.buffer], { type: image.mimeType }),
            config: { mimeType: image.mimeType },
          });
          imagePart = createPartFromUri(uploaded.uri, uploaded.mimeType);
        } else {
          imagePart = { inlineData: { mimeType: image.mimeType, data: image.base64 } };
        }
        // Image first, then text instructions.
        contents = [{ role: 'user', parts: [imagePart, { text: prompt }] }];
      }

      const response = await withTimeout(
        ai.models.generateContent({
          model,
          contents,
          config: { systemInstruction: SYSTEM_INSTRUCTION, temperature: 0.4 },
        }),
        timeoutMs
      );

      const text = (response?.text || '').trim();
      if (!text) {
        throw new GemmaError(
          'Gemma returned an empty answer (it may have been blocked by a safety filter). Try rephrasing your request.',
          { status: 502, code: 'EMPTY_RESPONSE' }
        );
      }
      return text;
    } catch (err) {
      throw mapSdkError(err);
    }
  }

  return {
    model,

    async explain({ topic, language, simpler = false, previous = '' }) {
      const text = await generate({ prompt: explainPrompt({ topic, language, simpler, previous }) });
      return { markdown: text };
    },

    async snap({ image, language, question }) {
      const text = await generate({ prompt: snapPrompt({ language, question }), image });
      const unclear = text.match(/^\s*UNCLEAR_IMAGE:\s*([\s\S]*)$/i);
      if (unclear) return { unclear: true, markdown: unclear[1].trim(), topic: '' };
      const topicMatch = text.match(/^\s*TOPIC:\s*(.+)$/im);
      const topic = topicMatch ? topicMatch[1].trim() : 'Textbook page';
      const markdown = text.replace(/^\s*TOPIC:.*$/im, '').trim();
      return { unclear: false, markdown, topic };
    },

    async notes({ topic, content, language }) {
      const text = await generate({ prompt: notesPrompt({ topic, content, language }) });
      return { markdown: text };
    },

    async quiz({ topic, content, language }) {
      let lastErr;
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const text = await generate({ prompt: quizPrompt({ topic, content, language }) });
        try {
          return { questions: validateQuiz(extractJson(text)) };
        } catch (err) {
          lastErr = err;
        }
      }
      throw new GemmaError(
        `Gemma's quiz was not in the expected format (${lastErr?.message}). Please try again.`,
        { status: 502, code: 'BAD_QUIZ_FORMAT' }
      );
    },

    async ping() {
      const started = Date.now();
      const text = await generate({ prompt: PING_PROMPT });
      return { reply: text, latencyMs: Date.now() - started };
    },
  };
}
