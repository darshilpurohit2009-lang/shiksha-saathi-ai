// Clearly-labelled sample outputs used ONLY when no Gemma API key is configured.
// These are static text written by the project authors. They are NOT AI output.

const LABEL = {
  english: '> **DEMO SAMPLE - not AI generated.** Add a `GEMINI_API_KEY` on the server to get live Gemma 4 answers for your own topic.\n\n',
  hindi: '> **डेमो नमूना - AI द्वारा नहीं बनाया गया।** अपने विषय पर असली Gemma 4 उत्तर पाने के लिए सर्वर पर `GEMINI_API_KEY` जोड़ें।\n\n',
  hinglish: '> **DEMO SAMPLE - AI generated nahi hai.** Apne topic ke live Gemma 4 jawab ke liye server par `GEMINI_API_KEY` add karein.\n\n',
};

const EXPLAIN = {
  english: `## In one line
Photosynthesis is how plants make their own food using sunlight, water and air.

## Step-by-step explanation
1. The roots take in **water** from the soil.
2. The leaves take in **carbon dioxide** from the air through tiny holes called stomata.
3. The green substance **chlorophyll** in the leaves catches sunlight.
4. Using that light energy, the plant turns water and carbon dioxide into **glucose** (sugar).
5. Oxygen is released into the air as a by-product.

## Example
A tulsi plant on your window sill is doing this right now: it uses morning sunlight to make the sugar it needs to grow.

## Key takeaways
- Plants need sunlight, water and carbon dioxide.
- Chlorophyll makes leaves green and captures light.
- Glucose is food; oxygen is released.`,
  hindi: `## एक पंक्ति में
प्रकाश संश्लेषण (photosynthesis) वह क्रिया है जिससे पौधे सूरज की रोशनी, पानी और हवा से अपना भोजन बनाते हैं।

## चरण-दर-चरण
1. जड़ें मिट्टी से **पानी** लेती हैं।
2. पत्तियाँ छोटे छिद्रों (स्टोमेटा) से हवा की **कार्बन डाइऑक्साइड** लेती हैं।
3. पत्तियों का हरा पदार्थ **क्लोरोफिल** सूर्य का प्रकाश पकड़ता है।
4. इस ऊर्जा से पौधा पानी और कार्बन डाइऑक्साइड को **ग्लूकोज़** (शर्करा) में बदलता है।
5. उप-उत्पाद के रूप में **ऑक्सीजन** हवा में निकलती है।

## उदाहरण
खिड़की पर रखा तुलसी का पौधा सुबह की धूप से अपना भोजन बना रहा है।

## मुख्य बातें
- पौधों को धूप, पानी और कार्बन डाइऑक्साइड चाहिए।
- क्लोरोफिल पत्तियों को हरा रंग देता है।
- ग्लूकोज़ भोजन है और ऑक्सीजन बाहर निकलती है।`,
  hinglish: `## Ek line mein
Photosynthesis woh process hai jisse plants sunlight, paani aur hawa se apna khana banate hain.

## Step by step
1. Roots mitti se **paani** lete hain.
2. Leaves chhote holes (stomata) se **carbon dioxide** lete hain.
3. Leaves ka green part **chlorophyll** sunlight pakadta hai.
4. Is energy se plant paani aur carbon dioxide ko **glucose** (sugar) mein badalta hai.
5. By-product ke roop mein **oxygen** bahar nikalti hai.

## Example
Khidki par rakha tulsi ka plant subah ki dhoop se apna khana bana raha hai.

## Key takeaways
- Plants ko sunlight, paani aur carbon dioxide chahiye.
- Chlorophyll leaves ko green rang deta hai.
- Glucose khana hai, oxygen bahar nikalti hai.`,
};

const SIMPLER = `## In one line
Plants cook their own food using sunlight.

## Think of it like this
A leaf is like a tiny kitchen. Sunlight is the gas flame, water and air are the ingredients, and sugar is the meal.

## Step by step
1. Water comes in from the roots.
2. Air comes in through the leaves.
3. Sunlight "cooks" them into sugar.

## Remember
No sunlight, no food for the plant.`;

const SNAP = `## What this page is about
(Demo) In live mode, Gemma 4 reads your uploaded textbook photo and explains what is on it. In demo mode your image is **not** analysed, so no explanation of your page is shown here.

## What to do next
- Add a \`GEMINI_API_KEY\` to the server's \`.env\` file.
- Restart the server and upload your photo again.`;

const NOTES = `## Summary
Photosynthesis lets plants turn light energy into chemical energy stored as glucose.

## Important definitions
- **Chlorophyll** - the green pigment that absorbs sunlight.
- **Stomata** - tiny pores on leaves that let gases in and out.
- **Glucose** - the sugar the plant makes as food.

## Key points
- Inputs: sunlight, water, carbon dioxide.
- Outputs: glucose and oxygen.
- Happens mainly in leaves, inside chloroplasts.

## Quick revision checklist
- I can name the inputs of photosynthesis.
- I can name the outputs.
- I can say what chlorophyll does.
- I can explain what stomata are.
- I can give one everyday example.`;

const QUIZ = [
  {
    question: 'Which gas do plants take in for photosynthesis?',
    options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Hydrogen'],
    correctIndex: 1,
    explanation: 'Plants absorb carbon dioxide through stomata. Oxygen is released, not absorbed, during photosynthesis.',
  },
  {
    question: 'What does chlorophyll do?',
    options: ['Stores water', 'Absorbs sunlight', 'Makes seeds', 'Absorbs minerals'],
    correctIndex: 1,
    explanation: 'Chlorophyll is the green pigment that captures light energy.',
  },
  {
    question: 'What is the sugar made in photosynthesis called?',
    options: ['Glucose', 'Starch only', 'Protein', 'Fat'],
    correctIndex: 0,
    explanation: 'Plants make glucose, which can later be stored as starch.',
  },
  {
    question: 'Which tiny openings let gases enter a leaf?',
    options: ['Roots', 'Veins', 'Stomata', 'Petals'],
    correctIndex: 2,
    explanation: 'Stomata are small pores, mostly on the underside of leaves.',
  },
  {
    question: 'Which is a by-product of photosynthesis?',
    options: ['Carbon dioxide', 'Oxygen', 'Smoke', 'Nitrogen'],
    correctIndex: 1,
    explanation: 'Oxygen is released into the air as a by-product.',
  },
].map((q, i) => ({ id: `q${i + 1}`, ...q }));

const pick = (lang) => (EXPLAIN[lang] ? lang : 'english');

export const demo = {
  explain: ({ language, simpler }) => ({
    markdown: LABEL[pick(language)] + (simpler ? SIMPLER : EXPLAIN[pick(language)]),
  }),
  snap: ({ language }) => ({
    unclear: false,
    topic: 'Demo sample (image not analysed)',
    markdown: LABEL[pick(language)] + SNAP,
  }),
  notes: ({ language }) => ({ markdown: LABEL[pick(language)] + NOTES }),
  quiz: () => ({ questions: QUIZ, note: 'Demo sample questions about photosynthesis - not AI generated.' }),
};
