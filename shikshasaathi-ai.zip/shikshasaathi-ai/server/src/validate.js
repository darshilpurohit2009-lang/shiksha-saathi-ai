export const LANGUAGES = ['english', 'hindi', 'hinglish'];
export const ALLOWED_MIME = ['image/jpeg', 'image/png', 'image/webp'];

export class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ValidationError';
    this.status = 400;
    this.code = 'INVALID_INPUT';
  }
}

export function cleanText(value, { field, max, required = true }) {
  if (value === undefined || value === null || value === '') {
    if (required) throw new ValidationError(`Please provide ${field}.`);
    return '';
  }
  if (typeof value !== 'string') throw new ValidationError(`${field} must be text.`);
  const text = value.trim();
  if (!text && required) throw new ValidationError(`Please provide ${field}.`);
  if (text.length > max) throw new ValidationError(`${field} is too long (max ${max} characters).`);
  return text;
}

export function cleanLanguage(value) {
  const lang = String(value || 'english').toLowerCase();
  if (!LANGUAGES.includes(lang)) {
    throw new ValidationError(`Language must be one of: ${LANGUAGES.join(', ')}.`);
  }
  return lang;
}

function sniffMime(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length > 8 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])))
    return 'image/png';
  if (buf.length > 12 && buf.slice(0, 4).toString('ascii') === 'RIFF' && buf.slice(8, 12).toString('ascii') === 'WEBP')
    return 'image/webp';
  return null;
}

// Validates a base64 image: declared MIME type, real file signature, and size.
export function cleanImage({ imageBase64, mimeType }, maxBytes) {
  if (!imageBase64 || typeof imageBase64 !== 'string') {
    throw new ValidationError('Please upload a textbook image.');
  }
  if (!ALLOWED_MIME.includes(mimeType)) {
    throw new ValidationError('Unsupported image type. Please upload a JPEG, PNG or WebP image.');
  }
  const b64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
  if (!/^[A-Za-z0-9+/=\s]+$/.test(b64)) throw new ValidationError('The image data is not valid base64.');
  const buffer = Buffer.from(b64, 'base64');
  if (buffer.length === 0) throw new ValidationError('The uploaded image is empty.');
  if (buffer.length > maxBytes) {
    throw new ValidationError(`Image is too large. Maximum size is ${Math.round(maxBytes / 1024 / 1024)} MB.`);
  }
  const sniffed = sniffMime(buffer);
  if (!sniffed) throw new ValidationError('That file does not look like a valid JPEG, PNG or WebP image.');
  if (sniffed !== mimeType) throw new ValidationError('The image content does not match its declared type.');
  return { buffer, mimeType: sniffed, base64: buffer.toString('base64') };
}
