import express from 'express';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import fs from 'node:fs';
import { demo } from './demo.js';
import { cleanText, cleanLanguage, cleanImage } from './validate.js';

/**
 * Builds the Express app.
 * @param {object} config  values from loadConfig()
 * @param {object|null} service  Gemma service (null => demo mode)
 */
export function createApp({ config, service, clientDist }) {
  const app = express();
  const live = Boolean(service) && config.liveConfigured;

  app.disable('x-powered-by');
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
  });
  // ~4 MB image as base64 plus text fields.
  app.use(express.json({ limit: '7mb' }));
  app.use(
    '/api',
    rateLimit({
      windowMs: 60_000,
      limit: 40,
      standardHeaders: true,
      legacyHeaders: false,
      message: { ok: false, code: 'RATE_LIMITED', error: 'Too many requests. Please slow down for a minute.' },
    })
  );

  const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res)).catch(next);

  // "model" is only reported when a real Gemma call just succeeded.
  const send = (res, payload) =>
    res.json({
      ok: true,
      mode: live ? 'live' : 'demo',
      aiGenerated: live,
      model: live ? config.model : null,
      ...payload,
    });

  app.get('/api/status', (_req, res) => {
    res.json({
      ok: true,
      mode: live ? 'live' : 'demo',
      model: live ? config.model : null,
      maxImageMB: Math.round(config.maxImageBytes / 1024 / 1024),
      reason: live ? null : config.forceDemo ? 'FORCE_DEMO_MODE is on' : 'No GEMINI_API_KEY configured on the server',
    });
  });

  app.post(
    '/api/explain',
    wrap(async (req, res) => {
      const topic = cleanText(req.body.topic, { field: 'a topic or question', max: 500 });
      const language = cleanLanguage(req.body.language);
      const simpler = req.body.simpler === true;
      const previous = cleanText(req.body.previous, { field: 'previous explanation', max: 8000, required: false });
      const result = live
        ? await service.explain({ topic, language, simpler, previous })
        : demo.explain({ language, simpler });
      send(res, { topic, ...result });
    })
  );

  app.post(
    '/api/snap',
    wrap(async (req, res) => {
      const language = cleanLanguage(req.body.language);
      const question = cleanText(req.body.question, { field: 'question', max: 500, required: false });
      const image = cleanImage(req.body, config.maxImageBytes);
      const result = live ? await service.snap({ image, language, question }) : demo.snap({ language });
      send(res, result);
    })
  );

  app.post(
    '/api/notes',
    wrap(async (req, res) => {
      const topic = cleanText(req.body.topic, { field: 'a topic', max: 300, required: false });
      const content = cleanText(req.body.content, { field: 'some content to make notes from', max: 8000 });
      const language = cleanLanguage(req.body.language);
      const result = live ? await service.notes({ topic, content, language }) : demo.notes({ language });
      send(res, { topic, ...result });
    })
  );

  app.post(
    '/api/quiz',
    wrap(async (req, res) => {
      const topic = cleanText(req.body.topic, { field: 'a topic', max: 300 });
      const content = cleanText(req.body.content, { field: 'content', max: 6000, required: false });
      const language = cleanLanguage(req.body.language);
      const result = live ? await service.quiz({ topic, content, language }) : demo.quiz();
      send(res, { topic, ...result });
    })
  );

  // Used by `npm run test:gemma` and for a quick health check. Live only.
  app.get(
    '/api/health/gemma',
    wrap(async (_req, res) => {
      if (!live) {
        return res.status(503).json({ ok: false, mode: 'demo', error: 'Gemma is not configured (demo mode).' });
      }
      const result = await service.ping();
      send(res, result);
    })
  );

  app.use('/api', (_req, res) => res.status(404).json({ ok: false, code: 'NOT_FOUND', error: 'Unknown API route.' }));

  // Serve the built client in production.
  const dist = clientDist && fs.existsSync(path.join(clientDist, 'index.html')) ? clientDist : null;
  if (dist) {
    app.use(express.static(dist));
    app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
  }

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err?.type === 'entity.too.large') {
      return res.status(413).json({ ok: false, code: 'TOO_LARGE', error: 'That upload is too large.' });
    }
    if (err?.type === 'entity.parse.failed') {
      return res.status(400).json({ ok: false, code: 'BAD_JSON', error: 'Invalid request body.' });
    }
    const status = err?.status && err.status >= 400 && err.status < 600 ? err.status : 500;
    if (status === 500) console.error('Unexpected error:', err?.message);
    res.status(status).json({
      ok: false,
      code: err?.code || 'SERVER_ERROR',
      error: status === 500 ? 'Something went wrong on the server.' : err.message,
    });
  });

  return app;
}
